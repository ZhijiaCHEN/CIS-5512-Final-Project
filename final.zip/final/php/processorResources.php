<?php
	session_start();
	/* release this code for content protection
	if ($_SESSION["RegState"] != 4) {
		$_SESSION["Message"] = "Please login first.";
		header("location:index.php");
		exit();
	} 
	*/ 
  if(!isset($_SESSION["login"]))
  {
  $_SESSION["RegState"] = 0;
  $_SESSION["Message"] = "Please login to Access this page";
  header("location:index.php");
  exit();
  }
  
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../js/favicon.ico">

    <title>CIS5512 Final</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/dashboard.css" rel="stylesheet">
	<link href="../css/lab4.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Group ID</a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="../php/clearAll.php" style="color: rgba(255,255,255,1);">Sign out</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" href="../dashboard.php">
                  <span data-feather="home"></span>
                  Dashboard 
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="../php/processorResources.php">
                  <span data-feather="book-open"></span>
                  Processors
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="../php/networkResources.php">
                  <span data-feather="book"></span>
                  Networks
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="crosshair"></span>
                  Run
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="bar-chart-2"></span>
                  Results
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="layers"></span>
                  Team Report
                </a>
              </li>
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Team Members</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle"></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="file-text"></span>
                  Member1 Report
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="file-text"></span>
                  Member2 Report
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="file-text"></span>
                  Member3 Report
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="file-text"></span>
                  Member4 Report
                </a>
              </li>
            </ul>
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <!--<div style="text-align:center;" id="messageLogin" class="alert alert-info mt-2" role="alert">Login successful</div>-->
		          
          <h2>Processor Resources</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>CPU(s)</th>
                  <th>Byte Order</th>
                  <th>Model</th>
                  <th>MHZ</th>
                  <th>BogoMIPS</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php exec("lscpu | grep -m 1 'CPU(s):' | sed 's/CPU(s)://g'",$o11); print_r($o11[0]);?></td>
                  <td><?php exec("lscpu | grep -m 1 'Byte Order:' | sed 's/Byte Order://g'",$o21); print_r($o21[0]);?></td>
                  <td><?php exec("lscpu | grep -m 1 'Model' | sed 's/Model://g'",$o31); print_r($o31[0]);?></td>
                  <td><?php exec("lscpu | grep -m 1 'MHz:' | sed 's/CPU MHz://g'",$o41); print_r($o41[0]);?></td>
    			  <td><?php exec("lscpu | grep -m 1 'BogoMIPS:' | sed 's/BogoMIPS://g'",$o51); print_r($o51[0]);?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../js/jquery-3.2.1.slim.min.js"></script>
    <script>window.jQuery || document.write('<script src="../js/jquery-slim.min.js"><\/script>')</script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="../js/feather.min.js"></script>
    <script>
      feather.replace()
    </script>    
  </body>
</html>