			 <thead>
                <tr>
                  <th>Interface</th>
                  <th>Receive Bytes</th>
                  <th>Errs</th>
                  <th>Drop</th>
                  <th>Transmit Bytes</th>
                  <th>Errs</th>
                  <th>Drop</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php exec("cat /proc/net/dev | sed 's/:.*//g'",$o1); print_r($o1[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $2}'",$o2); print_r($o2[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $4}'",$o3); print_r($o3[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $5}'",$o4); print_r($o4[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $10}'",$o5); print_r($o5[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $12}'",$o6); print_r($o6[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $13}'",$o7); print_r($o7[2]);?></td>                
				</tr>
                <tr>
                  <td><?php print_r($o1[3]);?></td>
                  <td><?php print_r($o2[3]);?></td>
                  <td><?php print_r($o3[3]);?></td>
                  <td><?php print_r($o4[3]);?></td>
                  <td><?php print_r($o5[3]);?></td>
                  <td><?php print_r($o6[3]);?></td>
                  <td><?php print_r($o7[3]);?></td>
                </tr>
                <tr>
                  <td><?php print_r($o1[4]);?></td>
              	  <td><?php print_r($o2[4]);?></td>
              	  <td><?php print_r($o3[4]);?></td>
              	  <td><?php print_r($o4[4]);?></td>
              	  <td><?php print_r($o5[4]);?></td>
              	  <td><?php print_r($o6[4]);?></td>
              	  <td><?php print_r($o7[4]);?></td>
                </tr>
              </tbody>