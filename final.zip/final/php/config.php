<?php
	define("USER", "tuj46253");
	define("SERVER","cis-linux2.temple.edu");
	define("PASSWORD", "ahatienu");
	define("DATABASE", "fa18_5512_tuj46253");
?>
