<?php
	define("USER", "tug87941");
	define("SERVER","cis-linux2.temple.edu");
	define("PASSWORD", "weegaibi");
	define("DATABASE", "fa18_5512_tug87941");
?>
