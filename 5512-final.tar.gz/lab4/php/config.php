<?php
	define("USER", "Your TUxxxxx");
	define("SERVER","cis-linux2.temple.edu");
	define("PASSWORD", "Your MySQL Password");
	define("DATABASE", "Your TUxxxx");
?>
