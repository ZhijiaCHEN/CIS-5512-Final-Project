<?php
session_start();
require_once("config.php");
// get web data 
/* mail = $_GET["Email"];
	$Acode = $_GET["Acode"];

	print "Pigon comes home ($Email $Acode)<br>";
	exit();
*/
?>