<?php
	define("USER", "tuj89290");
	define("SERVER","cis-linux2.temple.edu");
	define("PASSWORD", "kaozapie");
	define("DATABASE", "fa18_5512_tuj89290");
?>
