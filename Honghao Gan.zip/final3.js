var plot41b_state = 0;
var plot41c_state = 0;

$(document).ready(function(){
			$("#plot41b").click(function() {
		if (plot41b_state == 0) {
			plot41b_state ++;
			//$("#plot41b").html("Reset");
			$("#myChart").show();
			// make ajax/sync call
			event.preventDefault();
			$.ajax({
				type: 'GET', 
				url: 'plot41b.php',
				async: true,
				dataType: 'json',   
				encode: true
				}).always(function(data) {	
					// log data to the console so we can see
					console.log(data); 
					// here we will handle errors and validation messages
					var P = [];
					var ElapsedTime2 = [];
					var Size = 0;
					for (var i in data) {
							P.push(data[i].P);
							ElapsedTime2.push(data[i].ElapsedTime);
							Size = data[i].Size;
					}
					// alert("json returned. Size="+Size);
					/*
					var chartData = {
						labels: LoopOrder,
						datasets: [
						{
							label: "Elapsed Time",
							backgroundColor: 'rgba(200, 200, 200, 0.75)',
							borderColor: 'rgba(200, 200, 200, 0.75)',
							hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
							hoverBorderColor: 'rgba(200, 200, 200, 1)',
							data: ElapsedTime2
						}]
					};*/
					var ctx = document.getElementById("myChart");
					var myChart = new Chart(ctx, {
						type: 'bar',
						data: {
						  labels: P,
						  datasets: [{
							label: 'Processor vs Elapsed Time [N='+Size+']', 
							data: ElapsedTime2,
							lineTension: 0,
							backgroundColor: 'transparent',
							borderColor: '#007bff',
							borderWidth: 4,
							pointBackgroundColor: '#007bff'
						  }]
						},
						options: {
						  scales: {
							yAxes: [{
							  ticks: {
								beginAtZero: true
							  }
							}]
						  },
						  legend: {
							display: true,
							labels: {
								fontColor: 'rgb(255,99,132)'
							}
						  }
						}
					  });
				});
				event.preventDefault();			
		} else {  
			plot41b_state = 0;
			//$("#myChart").hide();
			$("#plot41b").html("Plot");
		}
    });
	
		$("#plot41c").click(function() {
		if (plot41c_state == 0) {
			plot41c_state ++;
			//$("#plot41c").html("Reset");
			//$("#myChart2").show();
			// make ajax/sync call
			event.preventDefault();
			$.ajax({
				type: 'GET', 
				url: 'plot41c.php',
				async: true,
				dataType: 'json',   
				encode: true
				}).always(function(data) {	
					// log data to the console so we can see
					console.log(data); 
					// here we will handle errors and validation messages
					
					var P = [];
					var MFLOPS = [];
					var Sizes = [];
					for (var i in data) {
							Sizes = data[i].Size;
							MFLOPS.push(data[i].MFLOPS);
							P.push(data[i].P);
					}
					// alert("json returned. Size="+Size);
					var ctx = document.getElementById("myChart2");
					var myChart = new Chart(ctx, {
						type: 'line',
						data: {
						  labels: P,
						  datasets: [{
							label: 'Processors vs. MFLOPS [N='+Sizes+']', 
							data: MFLOPS,
							lineTension: 0,
							backgroundColor: 'transparent',
							borderColor: '#007bff',
							borderWidth: 4,
							pointBackgroundColor: '#007bff'
						  }]
						},
						options: {
						  scales: {
							yAxes: [{
							  ticks: {
								beginAtZero: true
							  }
							}]
						  },
						  legend: {
							display: true,
							labels: {
								fontColor: 'rgb(255,99,132)'
							}
						  }
						}
					  });
				});
				event.preventDefault();			
		} else {  
			plot41c_state = 0;
			//$("#myChart2").hide();
			$("#plot41c").html("Plot");
		}
    });
	
	});