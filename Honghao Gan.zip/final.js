var Matrix_state = 0;


$(document).ready(function(){
	$("#Matrix").click(function(){
		if (Matrix_state == 0) {
			Matrix_state++;
			$("#Matrix").html("Reset");
			// make ajax/sync call
			event.preventDefault();
			var formData = {
				'P'  		: $('input[name=NumberOfHosts]').val(),
				'N'  		: $('input[name=MatrixSize]').val()
			};
			if (formData.P == ""|| formData.N == "") {
				alert("Please enter all fields then click Run");
				Matrix_state = 0;
				$("#Matrix").html("Run");
				return;
			}
			
			$.ajax({
				type: 'GET', 
				url: 'runACAN.php',
				async: true,
				data: formData,
				dataType: 'html',   
				encode: true
				}).always(function(data) {	
					// log data to the console so we can see
					console.log(data); 
					// here we will handle errors and validation messages
					$("#stdout").html(data);
				//	location.reload();
				});
			event.preventDefault();
		} else {
			Matrix_state = 0;
			$("#Matrix").html("Run");
			$("#stdout").html("");
			
		}
	})
	

	
});