
<?php
	header('Access-Control-Allow-Origin: *');
	session_start();
	 $P=$_GET["MatrixSize"];
	 $N=$_GET["NumberOfHosts"];
	 
	 $command="launch mmaster $P $N";
	 system($command);
	 
	 $command="launch mmworker $P $N";
	 system($command);
	
?>




