<?php
	session_start();

  
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="js/favicon.ico">

    <title>CIS5512 Final</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/dashboard.css" rel="stylesheet">
	<link href="css/lab4.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="js/final2.js"></script>
  </head>

  <body>
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Group ID</a>
      <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
      <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
          <a class="nav-link" href="php/clearAll.php" style="color: rgba(255,255,255,1);">Sign out</a>
        </li>
      </ul>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="php/processorResources.php">
                  <span data-feather="book-open"></span>
                  Processors
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="php/networkResources.php">
                  <span data-feather="book"></span>
                  Networks
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="php/run.php">
                  <span data-feather="crosshair"></span>
                  Run
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="php/result.php">
                  <span data-feather="bar-chart-2"></span>
                  Results
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="layers"></span>
                  Team Report
                </a>
              </li>
            </ul>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
              <span>Team Members</span>
              <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle"></span>
              </a>
            </h6>
            <ul class="nav flex-column mb-2">
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="file-text"></span>
                  Member1 Report
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="file-text"></span>
                  Member2 Report
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="file-text"></span>
                  Member3 Report
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="https://docs.google.com/document/d/1Dac_D2-RenCm8DRe1cHcNIr5Y44O4i77hSCcUSOeHRM/edit?usp=sharing">
                  <span data-feather="file-text"></span>
                  Member4 Report
                </a>
              </li>
            </ul>
          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
        <div style="text-align:center;" id="messageLogin" class="alert alert-info mt-2" role="alert">Login successful</div>
		<h2>Processor Resources</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>CPU(s)</th>
                  <th>Byte Order</th>
                  <th>Model</th>
                  <th>MHZ</th>
                  <th>BogoMIPS</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php exec("lscpu | grep -m 1 'CPU(s):' | sed 's/CPU(s)://g'",$o11); print_r($o11[0]);?></td>
                  <td><?php exec("lscpu | grep -m 1 'Byte Order:' | sed 's/Byte Order://g'",$o21); print_r($o21[0]);?></td>
                  <td><?php exec("lscpu | grep -m 1 'Model:' | sed 's/Model://g'",$o31); print_r($o31[0]);?></td>
                  <td><?php exec("lscpu | grep -m 1 'MHz:' | sed 's/CPU MHz://g'",$o41); print_r($o41[0]);?></td>
    			  <td><?php exec("lscpu | grep -m 1 'BogoMIPS:' | sed 's/BogoMIPS://g'",$o51); print_r($o51[0]);?></td>
                </tr>
              </tbody>
            </table>
          </div>
          <h2>Network Resources</h2> <a href="#" id="refresh"><span id="refresh" data-feather="bar-chart-2"></span>(Refresh)</a>
          <div class="table-responsive"> 
            <table class="table table-striped table-sm" id="networkTable">
              <thead>
                <tr>
                  <th>Interface</th>
                  <th>Receive Bytes</th>
                  <th>Errs</th>
                  <th>Drop</th>
                  <th>Transmit Bytes</th>
                  <th>Errs</th>
                  <th>Drop</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php exec("cat /proc/net/dev | sed 's/:.*//g'",$o1); print_r($o1[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $2}'",$o2); print_r($o2[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $4}'",$o3); print_r($o3[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $5}'",$o4); print_r($o4[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $10}'",$o5); print_r($o5[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $12}'",$o6); print_r($o6[2]);?></td>
                  <td><?php exec("cat /proc/net/dev | awk '{print $13}'",$o7); print_r($o7[2]);?></td>                
				</tr>
                <tr>
                  <td><?php print_r($o1[3]);?></td>
                  <td><?php print_r($o2[3]);?></td>
                  <td><?php print_r($o3[3]);?></td>
                  <td><?php print_r($o4[3]);?></td>
                  <td><?php print_r($o5[3]);?></td>
                  <td><?php print_r($o6[3]);?></td>
                  <td><?php print_r($o7[3]);?></td>
                </tr>
                <tr>
                  <td><?php print_r($o1[4]);?></td>
              	  <td><?php print_r($o2[4]);?></td>
              	  <td><?php print_r($o3[4]);?></td>
              	  <td><?php print_r($o4[4]);?></td>
              	  <td><?php print_r($o5[4]);?></td>
              	  <td><?php print_r($o6[4]);?></td>
              	  <td><?php print_r($o7[4]);?></td>
                </tr>
              </tbody>
            </table>
          </div>
          <h2 class="h2" >Run Application</h2>
		  <div class="card" style="width: 500px;">
			<div class="card-header">
				Parallel Dense Matrix Multiplication
			</div>
			<div class="card-body"> 
				<form action="#" method="get" class=" form-signin">
					<div class="row">
						<input type="number" id="inputMatrixSize" name="MatrixSize" class="col form-control" placeholder="matrix size(N)" required autofocus>
						
					</div>
					<div class="row">
						<input type="number" id="inputNumberOfHosts" name="NumberOfHosts" class="col form-control mt-2" placeholder="number of hosts(P)" required>
						
					</div>
				   
				  <button type="submit" button id="Matrix" class="btn btn-lg btn-primary btn-block mt-2" type="submit">Run</button>
				</form>
			</div> 
		  </div>
		  <div id="resultCard" class="card" style="width: 500px;">
			<div class="card-header">
				Runtime	Monitor
			</div>
			<div id="stdout" class="card-body">

			</div>
		  </div>
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Performance Results</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <button class="btn btn-sm btn-outline-secondary">Share</button>
                <button class="btn btn-sm btn-outline-secondary">Export</button>
              </div>
              <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                Scalability Charts
              </button>
            </div>
          </div>
		  <button id="plot41b" class="btn btn-primary btn-block">Plot</button>
          <canvas class="my-4" id="myChart" width="900" height="380"></canvas>
		  <button id="plot41c" class="btn btn-primary btn-block">Plot</button>
		  <canvas class="my-4" id="myChart2" width="900" height="380"></canvas>

        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.2.1.slim.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-slim.min.js"><\/script>')</script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="js/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- Graphs -->
    <script src="js/Chart.min.js"></script>

    
    <!-- Refresh network resources -->
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script>
        $("#refresh").click( function()
           {
				$("#networkTable").load("php/networkTable.php");
           }
        );
    </script>
           
  </body>
</html>