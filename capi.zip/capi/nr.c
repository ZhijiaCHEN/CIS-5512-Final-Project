#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
    system("cat /proc/net/dev");
    return 0;
}
