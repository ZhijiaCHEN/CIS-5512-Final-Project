#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
    system("lscpu");
    return 0;
}
