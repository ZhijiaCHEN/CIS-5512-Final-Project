<?php

exec('exec gcc -o nr nr.c');
exec('./nr',$out);

print_r($out);





?>


