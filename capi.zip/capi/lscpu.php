<?php

exec('exec gcc -o lscpu lscpu.c');
exec('./lscpu',$out);

print_r($out[3]);
print_r("\n");

print_r($out[2]);
print_r("\n");

print_r($out[12]);
print_r("\n");

print_r($out[14]);

print_r("\n");
print_r($out[15]);




?>


