#define Linux     1
#define SunOs     0
#define Ultrix    0
#define OSF1      0
#define AIX       0
#define EPIX      0
typedef unsigned char sng_int8 ;
typedef unsigned short sng_int16 ;
typedef unsigned int sng_int32 ;
typedef unsigned int sng_int64 ;
typedef int sng_ints32 ;
typedef int sng_ints64 ;
